# Bot Framework Migration from V3 to V4

## Redirect

This page has moved to [../Migration/MigrationV3V4](../Migration/MigrationV3V4).