module.exports = function (session) {
    session.error('Flights Dialog is not implemented and is instead being used to show Bot error handling');
};