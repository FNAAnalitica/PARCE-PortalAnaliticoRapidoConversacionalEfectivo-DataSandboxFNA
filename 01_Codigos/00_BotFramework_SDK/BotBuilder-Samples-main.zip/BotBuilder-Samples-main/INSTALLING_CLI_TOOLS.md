
## Installing the Bot Framework CLI  tools

To learn more about the Bot Framework Command Line Tools, please visit the [BF CLI github repository](https://aka.ms/bfcli) or the [BF CLI Overview documentation](https://docs.microsoft.com/en-us/azure/bot-service/bf-cli-overview). 


## Legacy CLI Tools

__The following page is about the legacy tools.__

The older, legacy, CLI tools can be found here:
https://github.com/Microsoft/botbuilder-tools
