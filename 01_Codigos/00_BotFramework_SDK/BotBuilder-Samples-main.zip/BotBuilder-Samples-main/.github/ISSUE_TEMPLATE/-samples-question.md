---
name: "Bot Builder Samples - Question"
about: The issue tracker is not for questions. Please ask questions on https://stackoverflow.com/questions/tagged/botframework

---

🚨 The issue tracker is not for questions 🚨

If you have a question, please ask it on https://stackoverflow.com/questions/tagged/botframework

[question]
