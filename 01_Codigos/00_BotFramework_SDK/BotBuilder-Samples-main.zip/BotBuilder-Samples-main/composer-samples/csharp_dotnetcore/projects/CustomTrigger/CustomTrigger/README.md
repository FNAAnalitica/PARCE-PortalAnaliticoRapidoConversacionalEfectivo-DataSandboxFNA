# MemberUpdates

This sample demonstrates a custom trigger for [Bot Framework Composer](https://docs.microsoft.com/composer).

## Getting started

Refer to the [README](../README.md) for a full description of creating a custom triggers.

## Feedback and issues

If you encounter any issues with this project, or would like to share any feedback please open an Issue in our [GitHub repository](https://github.com/microsoft/botbuilder-samples/issues/new/choose).
